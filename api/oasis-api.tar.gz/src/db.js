require("dotenv").config();
const { Sequelize } = require("sequelize");
const fs = require("fs");
const path = require("path");
const { DB_USER, DB_PASSWORD, DB_HOST,DB_PORT,DB_NAME } = process.env;

const sequelize = new Sequelize(
  `postgres://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}`,
  {
    logging: false, // set to console.log to see the raw SQL queries
    native: false, // lets Sequelize know we can use pg-native for ~30% more speed
  }
);
const basename = path.basename(__filename);

const modelDefiners = [];

// Leemos todos los archivos de la carpeta Models, los requerimos y agregamos al arreglo modelDefiners
fs.readdirSync(path.join(__dirname, "/models"))
  .filter(
    (file) =>
      file.indexOf(".") !== 0 && file !== basename && file.slice(-3) === ".js"
  )
  .forEach((file) => {
    modelDefiners.push(require(path.join(__dirname, "/models", file)));
  });

// Injectamos la conexion (sequelize) a todos los modelos
modelDefiners.forEach((model) => model(sequelize));
// Capitalizamos los nombres de los modelos ie: product => Product
let entries = Object.entries(sequelize.models);
let capsEntries = entries.map((entry) => [
  entry[0][0].toUpperCase() + entry[0].slice(1),
  entry[1],
]);
sequelize.models = Object.fromEntries(capsEntries);

// En sequelize.models están todos los modelos importados como propiedades
// Para relacionarlos hacemos un destructuring
const { Book, Author, Genre, Shopping_cart, User, Reviews, Favorites } = sequelize.models;

// Aca vendrian las relaciones
//Relacion entre Book y Genre de muchos a muchos
Book.belongsToMany(Genre, { through: "BookGenre" });
Genre.belongsToMany(Book, { through: "BookGenre" });

Author.hasMany(Book, { as: "libro" })
Book.belongsTo(Author, { as: "autor" })

// Shopping_cart.belongsToMany(Book, { through: 'CartBook'});
// Book.belongsToMany(Shopping_cart, { through: 'CartBook'});

// User.hasMany(Shopping_cart);
// Shopping_cart.belongsTo(User);

Book.belongsToMany(User, { through: { model: Shopping_cart, unique: false } })
User.belongsToMany(Book, { through: { model: Shopping_cart, unique: false } })

User.hasMany(Reviews);
Reviews.belongsTo(User);

Book.hasMany(Reviews);
Reviews.belongsTo(Book);

User.hasMany(Favorites, { as: "favoritos", foreignKey: "usuarioId" });
Favorites.belongsTo(User, { as: "usuario"});

Book.hasMany(Favorites, { as: "favoritos", foreignKey: "libroId" });
Favorites.belongsTo(Book, { as: "libro"});

// Product.hasMany(Reviews);
//.
module.exports = {
  ...sequelize.models, // para poder importar los modelos así: const { Product, User } = require('./db.js');
  conn: sequelize, // para importart la conexión { conn } = require('./db.js');
};
